# Control_OS
Programa de ordem de serviço feito em Python e utlizando o banco de dados MySql.
